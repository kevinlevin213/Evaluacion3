package com.RefugioHuellasFelices.controller;

import com.RefugioHuellasFelices.Assemblers.RazaModelAssembler;
import com.RefugioHuellasFelices.model.Raza;
import com.RefugioHuellasFelices.service.RazaService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/razas")

public class RazaControllerV2 {

    @Autowired
    private RazaService razaService;

    @Autowired
    private RazaModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Raza>> findAllRaza() {
        List<EntityModel<Raza>> razas = razaService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(razas,
                linkTo(methodOn(RazaControllerV2.class).findAllRaza()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> findRazaById(@PathVariable Long id) {
        Raza raza = razaService.findById(id);
        if (raza == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(raza));
    }

    @GetMapping(value = "/nombre/{nombreRaza}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Raza>> findByNombreRaza(@PathVariable String nombreRaza) {
        List<EntityModel<Raza>> razas = razaService.findByNombreRaza(nombreRaza).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(
                razas,
                linkTo(methodOn(RazaControllerV2.class).findByNombreRaza(nombreRaza)).withSelfRel()
        );
    }

    @GetMapping(value = "/especie/{especie}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Raza>> findByEspecie(@PathVariable String especie) {
        List<EntityModel<Raza>> razas = razaService.buscarPorNombreEspecie(especie).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(
                razas,
                linkTo(methodOn(RazaControllerV2.class).findByEspecie(especie)).withSelfRel()
        );
    }

    @GetMapping(value = "/nombre/{nombre}/especie/{especie}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Raza>> findByNombreAndEspecie(@PathVariable String nombre, @PathVariable String especie) {
        List<EntityModel<Raza>> razas = razaService.findByNombreRazaAndEspecie_NombreEspecie(nombre, especie).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(
                razas,
                linkTo(methodOn(RazaControllerV2.class).findByNombreAndEspecie(nombre, especie)).withSelfRel()
        );
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> createRaza(@RequestBody Raza raza) {
        Raza nueva = razaService.save(raza);
        return ResponseEntity
                .created(linkTo(methodOn(RazaControllerV2.class).findRazaById(nueva.getId().longValue())).toUri())
                .body(assembler.toModel(nueva));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> updateRaza(@PathVariable Long id, @RequestBody Raza raza) {
        raza.setId(id);
        Raza actualizada = razaService.save(raza);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(actualizada));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Raza>> patchRaza(@PathVariable Long id, @RequestBody Raza raza) {
        Raza actualizada = razaService.patchRaza(id, raza);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(actualizada));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<Void> deleteRaza(@PathVariable Long id) {
        Raza existente = razaService.findById(id);
        if (existente == null) {
            return ResponseEntity.notFound().build();
        }
        razaService.delete(id);
        return ResponseEntity.noContent().build();
    }

}

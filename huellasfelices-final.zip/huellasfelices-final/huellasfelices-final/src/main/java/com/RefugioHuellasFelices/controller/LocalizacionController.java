package com.RefugioHuellasFelices.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import com.RefugioHuellasFelices.model.Localizacion;
import com.RefugioHuellasFelices.service.LocalizacionService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/localizaciones")
@Tag(name = "Localizaciones", description = "Operaciones relacionadas con las localizaciones")
public class LocalizacionController {

    @Autowired
    private LocalizacionService localizacionService;

    @GetMapping
    @Operation(summary = "Listar localizaciones", description = "Obtiene una lista de todas las localizaciones")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No hay localizaciones para listar") 
    })
    public ResponseEntity<List<Localizacion>> listar(){
        List <Localizacion> localizacions = localizacionService.findAll();
        if(localizacions.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(localizacions);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener localización", description = "Obtiene una localización por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "404", description = "Localización no encontrada") 
    })
    public ResponseEntity<Localizacion> buscar(@PathVariable Long id){
        try{
            Localizacion localizacion = localizacionService.findById(id);
            return ResponseEntity.ok(localizacion);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/ciudad/{ciudad}")
    @Operation(summary = "Buscar localización por ciudad", description = "Obtiene una localización que coincide con la ciudad especificada")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontró localización para esa ciudad") 
    })
    public ResponseEntity<Localizacion> buscarPorCiudad(@PathVariable String ciudad) {
        Localizacion localizacion = localizacionService.findByCiudad(ciudad);
        if (localizacion == null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(localizacion);
    }

    @GetMapping("/comuna/{comuna}")
    @Operation(summary = "Buscar localizaciones por comuna", description = "Obtiene localizaciones que coinciden con la comuna especificada")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontraron localizaciones para esa comuna") 
    })
    public ResponseEntity<List<Localizacion>> buscarPorComuna(@PathVariable String comuna) {
        List<Localizacion> localizaciones = localizacionService.findByComuna(comuna);
        if (localizaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(localizaciones);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva localización", description = "Crea un nuevo registro de localización")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Localización creada exitosamente"),
        @ApiResponse(responseCode = "400", description = "Error en la creación de la localización") 
    })
    public ResponseEntity<Localizacion> guardar(@RequestBody Localizacion localizacion) {
        Localizacion localizacionNuevo = localizacionService.save(localizacion);
        return ResponseEntity.status(HttpStatus.CREATED).body(localizacionNuevo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una localización", description = "Actualiza todos los datos de una localización existente")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Localización actualizada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Localización no encontrada para actualizar") 
    })
    public ResponseEntity<Localizacion> actualizar(@PathVariable Long id, @RequestBody Localizacion localizacion){
        try{
            localizacionService.save(localizacion);
            return ResponseEntity.ok(localizacion);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Actualizar parcialmente una localización", description = "Actualiza ciertos campos de una localización")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Localización actualizada parcialmente"),
        @ApiResponse(responseCode = "404", description = "Localización no encontrada para actualización parcial") 
    })
    public ResponseEntity<Localizacion> patchLocalizacion(@PathVariable Long id, @RequestBody Localizacion partialLocalizacion) {
        try {
            Localizacion updatedLocalizacion = localizacionService.patchLocalizacion(id, partialLocalizacion);
            return ResponseEntity.ok(updatedLocalizacion);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una localización", description = "Elimina una localización por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "204", description = "Localización eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Localización no encontrada para eliminar") 
    })
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            localizacionService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    //Metodos agreado al controller
    @GetMapping("/comuna/{comuna}/ciudad/{ciudad}")
    @Operation(summary = "Buscar localizaciones por comuna y ciudad", description = "Obtiene localizaciones filtradas por comuna y ciudad")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontraron localizaciones para los filtros indicados") 
    })
    public ResponseEntity<List<Localizacion>> buscarPorComunaYCiudad(@PathVariable String comuna, @PathVariable String ciudad) {
        List<Localizacion> localizaciones = localizacionService.findByComunaAndCiudad(comuna, ciudad);
        if (localizaciones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(localizaciones);
    }

}

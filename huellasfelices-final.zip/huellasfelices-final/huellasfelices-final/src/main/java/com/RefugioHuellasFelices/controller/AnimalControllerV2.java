package com.RefugioHuellasFelices.controller;

import com.RefugioHuellasFelices.Assemblers.AnimalModelAssembler;
import com.RefugioHuellasFelices.model.Animal;
import com.RefugioHuellasFelices.service.AnimalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/animales")
public class AnimalControllerV2 {

    @Autowired
    private AnimalService animalService;

    @Autowired
    private AnimalModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<CollectionModel<EntityModel<Animal>>> findAllAnimales() {
        List<EntityModel<Animal>> animales = animalService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(CollectionModel.of(animales,
                linkTo(methodOn(AnimalControllerV2.class).findAllAnimales()).withSelfRel()));
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> findAnimalById(@PathVariable Long id) {
        Animal animal = animalService.findById(id);
        if (animal == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(animal));
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> createAnimal(@RequestBody Animal animal) {
        Animal nuevo = animalService.save(animal);
        return ResponseEntity
                .created(linkTo(methodOn(AnimalControllerV2.class).findAnimalById(nuevo.getId())).toUri())
                .body(assembler.toModel(nuevo));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> updateAnimal(@PathVariable Long id, @RequestBody Animal animal) {
        animal.setId(id);
        Animal actualizado = animalService.save(animal);
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Animal>> patchAnimal(@PathVariable Long id, @RequestBody Animal partialAnimal) {
        Animal actualizado = animalService.patchAnimal(id, partialAnimal);
        if (actualizado == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(actualizado));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<Void> deleteAnimal(@PathVariable Long id) {
        Animal existente = animalService.findById(id);
        if (existente == null) {
            return ResponseEntity.notFound().build();
        }
        animalService.delete(id);
        return ResponseEntity.noContent().build();
    }


    @GetMapping("/resumen")
    public ResponseEntity<List<Map<String, Object>>> resumen() {
        List<Map<String, Object>> resumen = animalService.findAnimalConDireccion();
        if (resumen.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(resumen);
    }

    @GetMapping("/ciudad/{ciudad}/raza/{raza}")
    public ResponseEntity<List<Animal>> buscarPorCiudadYRaza(@PathVariable String ciudad, @PathVariable String raza) {
        List<Animal> animales = animalService.buscarPorCiudadYNombreRaza(ciudad, raza);
        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(animales);
    }

    @GetMapping("/adoptados/ciudad/{ciudad}")
    public ResponseEntity<List<Animal>> buscarAdoptadosEnCiudad(@PathVariable String ciudad) {
        List<Animal> animales = animalService.buscarAnimalesAdoptadosEnCiudad(ciudad);
        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(animales);
    }

    @GetMapping("/nombre/{nombre}/raza/{raza}")
    public ResponseEntity<List<Animal>> buscarPorNombreYRaza(@PathVariable String nombre, @PathVariable String raza) {
        List<Animal> animales = animalService.findByNombreAnimalAndRaza_NombreRaza(nombre, raza);
        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(animales);
    }
}

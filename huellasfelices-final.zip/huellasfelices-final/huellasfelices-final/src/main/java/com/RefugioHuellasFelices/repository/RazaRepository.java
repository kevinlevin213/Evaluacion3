package com.RefugioHuellasFelices.repository;

import java.util.List;
import com.RefugioHuellasFelices.model.Raza;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface RazaRepository extends JpaRepository<Raza, Long> {
    
    List<Raza> findByNombreRaza(String nombreRaza);

    // Esta consulta busca todas las razas que pertenecen a una especie específica.
    // Hace JOIN Raza -> Especie (ManyToOne).
    @Query("SELECT r FROM Raza r " +
        "JOIN r.especie e " +                      // JOIN con la tabla 'especie'
        "WHERE e.nombreEspecie = :nombreEspecie")  // Filtra por el nombre de la especie
    List<Raza> buscarPorNombreEspecie(@Param("nombreEspecie") String nombreEspecie);


    //metodo con minimo 2 parametros
    List<Raza> findByNombreRazaAndEspecie_NombreEspecie(String raza, String especie);
}

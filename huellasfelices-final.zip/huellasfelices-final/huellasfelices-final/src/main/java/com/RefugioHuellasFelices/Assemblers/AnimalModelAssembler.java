package com.RefugioHuellasFelices.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.RefugioHuellasFelices.controller.AnimalControllerV2;
import com.RefugioHuellasFelices.model.Animal;

@Component
public class AnimalModelAssembler implements RepresentationModelAssembler<Animal, EntityModel<Animal>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Animal> toModel(Animal animal) {
        return EntityModel.of(animal,
        linkTo(methodOn(AnimalControllerV2.class).findAnimalById(animal.getId())).withSelfRel(),
        linkTo(methodOn(AnimalControllerV2.class).findAllAnimales()).withRel("animales"),
        linkTo(methodOn(AnimalControllerV2.class).updateAnimal(animal.getId(), animal)).withRel("actualizar"), 
        linkTo(methodOn(AnimalControllerV2.class).deleteAnimal(animal.getId())).withRel("eliminar"), 
        linkTo(methodOn(AnimalControllerV2.class).patchAnimal(animal.getId(), animal)).withRel("actualizar-parcial")
        );
    }
}

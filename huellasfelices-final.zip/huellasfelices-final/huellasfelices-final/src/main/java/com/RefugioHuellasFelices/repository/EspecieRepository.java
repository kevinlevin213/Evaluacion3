package com.RefugioHuellasFelices.repository;

import java.util.List;
import com.RefugioHuellasFelices.model.Especie;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface EspecieRepository extends JpaRepository<Especie, Long> {
    
    List<Especie> findByNombreEspecie(String nombreEspecie);
}

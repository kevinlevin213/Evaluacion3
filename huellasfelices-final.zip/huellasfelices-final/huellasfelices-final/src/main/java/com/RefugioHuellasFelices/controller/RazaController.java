package com.RefugioHuellasFelices.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import com.RefugioHuellasFelices.model.Raza;
import com.RefugioHuellasFelices.service.RazaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/razas")
@Tag(name = "Razas", description = "Operaciones relacionadas con las razas")
public class RazaController {

    @Autowired
    private RazaService razaService;

    @GetMapping
    @Operation(summary = "Listar razas", description = "Obtiene una lista de todas las razas")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No hay razas para listar")
    })
    public ResponseEntity<List<Raza>> listar(){
        List<Raza> razas = razaService.findAll();
        if(razas.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(razas);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener raza", description = "Obtiene una raza por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "404", description = "Raza no encontrada")
    })
    public ResponseEntity<Raza> buscar(@PathVariable Long id){
        try{
            Raza raza = razaService.findById(id);
            return ResponseEntity.ok(raza);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/nombre/{nombreRaza}")
    @Operation(summary = "Buscar razas por nombre", description = "Obtiene razas que coinciden con el nombre especificado")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontraron razas para ese nombre")
    })
    public ResponseEntity<List<Raza>> buscarPorNombreRaza(@PathVariable String nombreRaza) {
        List<Raza> razas = razaService.findByNombreRaza(nombreRaza);
        if (razas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(razas);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva raza", description = "Crea un nuevo registro de raza")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Raza creada exitosamente"),
        @ApiResponse(responseCode = "400", description = "Error en la creación de la raza")
    })
    public ResponseEntity<Raza> guardar(@RequestBody Raza raza) {
        Raza razaNuevo = razaService.save(raza);
        return ResponseEntity.status(HttpStatus.CREATED).body(razaNuevo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una raza", description = "Actualiza todos los datos de una raza existente")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Raza actualizada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Raza no encontrada para actualizar")
    })
    public ResponseEntity<Raza> actualizar(@PathVariable Long id, @RequestBody Raza raza){
        try{
            razaService.save(raza);
            return ResponseEntity.ok(raza);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Actualizar parcialmente una raza", description = "Actualiza ciertos campos de una raza")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Raza actualizada parcialmente"),
        @ApiResponse(responseCode = "404", description = "Raza no encontrada para actualización parcial")
    })
    public ResponseEntity<Raza> patchRaza(@PathVariable Long id, @RequestBody Raza partialRaza) {
        try {
            Raza updatedRaza = razaService.patchRaza(id, partialRaza);
            return ResponseEntity.ok(updatedRaza);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una raza", description = "Elimina una raza por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "204", description = "Raza eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Raza no encontrada para eliminar")
    })
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            razaService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    //Nuevos metodos agregados
    @GetMapping("/especie/{especie}")
    @Operation(summary = "Buscar razas por especie", description = "Obtiene razas que pertenecen a la especie indicada")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontraron razas para esa especie")
    })
    public ResponseEntity<List<Raza>> buscarPorEspecie(@PathVariable String especie) {
        List<Raza> razas = razaService.buscarPorNombreEspecie(especie);
        if (razas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(razas);
    }

    @GetMapping("/nombre/{nombre}/especie/{especie}")
    @Operation(summary = "Buscar razas por nombre y especie", description = "Obtiene razas que coinciden con el nombre y especie indicados")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontraron razas para esos filtros")
    })
    public ResponseEntity<List<Raza>> buscarPorNombreYEspecie(@PathVariable String nombre, @PathVariable String especie) {
        List<Raza> razas = razaService.findByNombreRazaAndEspecie_NombreEspecie(nombre, especie);
        if (razas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(razas);
    }

}

package com.RefugioHuellasFelices;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.RefugioHuellasFelices.model.Animal;
import com.RefugioHuellasFelices.model.Categoria;
import com.RefugioHuellasFelices.model.Especie;
import com.RefugioHuellasFelices.model.Localizacion;
import com.RefugioHuellasFelices.model.Raza;
import com.RefugioHuellasFelices.model.Usuario;
import com.RefugioHuellasFelices.repository.AnimalRepository;
import com.RefugioHuellasFelices.repository.CategoriaRepository;
import com.RefugioHuellasFelices.repository.EspecieRepository;
import com.RefugioHuellasFelices.repository.LocalizacionRepository;
import com.RefugioHuellasFelices.repository.RazaRepository;
import com.RefugioHuellasFelices.repository.UsuarioRepository;

import net.datafaker.Faker;

@Profile("!test")
@Component
public class DataLoader implements CommandLineRunner {

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private EspecieRepository especieRepository;

    @Autowired
    private RazaRepository razaRepository;

    @Autowired
    private LocalizacionRepository localizacionRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private AnimalRepository animalRepository;

    Faker faker = new Faker();
    Random random = new Random();

    @Override
    public void run(String... args) throws Exception {
        
        //1. categorias
        for (int i = 0; i < 3; i++) {
            Categoria categoria = new Categoria();
            categoria.setNombreCategoria(faker.company().industry());
            categoriaRepository.save(categoria);
        }

        for (int i = 0; i < 3; i++) {
            Especie especie = new Especie();
            especie.setNombreEspecie(faker.animal().name());
            especieRepository.save(especie);
        }
        List<Especie> especies = especieRepository.findAll();

        for (int i = 0; i < 5; i++) {
            Raza raza = new Raza();
            raza.setNombreRaza(faker.dog().breed());
            raza.setEspecie(especies.get(random.nextInt(especies.size())));
            razaRepository.save(raza);
        }

        for (int i = 0; i < 5; i++) {
            Localizacion localizacion = new Localizacion();
            localizacion.setDireccion(faker.address().streetAddress());
            localizacion.setComuna(faker.address().cityName());
            localizacion.setCiudad(faker.address().state());
            localizacionRepository.save(localizacion);
        }

        List<Categoria> categorias = categoriaRepository.findAll();
        for (int i = 0; i < 5; i++) {
            Usuario usuario = new Usuario();
            usuario.setRun(faker.idNumber().valid());
            usuario.setNombres(faker.name().firstName());
            usuario.setApellidos(faker.name().lastName());
            usuario.setCorreo(faker.internet().emailAddress());
            usuario.setContraseña(faker.internet().password());
            usuario.setTelefono(faker.phoneNumber().cellPhone());
            usuario.setCiudad(faker.address().cityName());
            usuario.setCategoria(categorias.get(random.nextInt(categorias.size())));
            usuarioRepository.save(usuario);
        }

        List<Raza> razas = razaRepository.findAll();
        List<Localizacion> localizaciones = localizacionRepository.findAll();
        List<Usuario> usuarios = usuarioRepository.findAll();

        for (int i = 0; i < 10; i++) {
            Animal animal = new Animal();
            animal.setNombreAnimal(faker.animal().name());
            animal.setLocalizacion(localizaciones.get(random.nextInt(localizaciones.size())));
            animal.setRaza(razas.get(random.nextInt(razas.size())));
            animal.setUsuario(random.nextBoolean() ? usuarios.get(random.nextInt(usuarios.size())) : null);
            animalRepository.save(animal);
        }
    }
}

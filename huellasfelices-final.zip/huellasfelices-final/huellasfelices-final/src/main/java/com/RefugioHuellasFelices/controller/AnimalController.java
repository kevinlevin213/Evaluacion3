package com.RefugioHuellasFelices.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import com.RefugioHuellasFelices.model.Animal;
import com.RefugioHuellasFelices.service.AnimalService;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/animales")
@Tag(name = "Animales", description = "Operaciones relacionadas con los animales")
public class AnimalController {

    @Autowired
    private AnimalService animalService;

    @GetMapping
    @Operation(summary = "Listar animales", description = "Obtiene una lista de todos los animales")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"), 
        @ApiResponse(responseCode = "204", description = "No hay animales para listar") 
    }) 
    public ResponseEntity<List<Animal>> listar(){
        List <Animal> animales = animalService.findAll();
        if(animales.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(animales);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener animal", description = "Obtiene un animal por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"), 
        @ApiResponse(responseCode = "404", description = "Animal no encontrado") 
    }) 
    public ResponseEntity<Animal> buscar(@PathVariable Long id){
        try{
            Animal animal = animalService.findById(id);
            return ResponseEntity.ok(animal);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    
    @GetMapping("/resumen")
    @Operation(summary = "Resumen de animales con dirección", description = "Obtiene un resumen de animales junto con su dirección")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"), 
        @ApiResponse(responseCode = "204", description = "No hay datos para mostrar") 
    }) 
    public ResponseEntity<List<Map<String, Object>>> resumen() {
        List<Map<String, Object>> resumen = animalService.findAnimalConDireccion();
        if (resumen.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(resumen);
    }

    @PostMapping
    @Operation(summary = "Crear un nuevo animal", description = "Crea un nuevo registro de animal")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Animal creado exitosamente"), 
        @ApiResponse(responseCode = "400", description = "Error en la creación del animal") 
    }) 
    public ResponseEntity<Animal> guardar(@RequestBody Animal animal) {
        Animal animalNuevo = animalService.save(animal);
        return ResponseEntity.status(HttpStatus.CREATED).body(animalNuevo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar un animal", description = "Actualiza todos los datos de un animal existente")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Animal actualizado exitosamente"), 
        @ApiResponse(responseCode = "404", description = "Animal no encontrado para actualizar") 
    }) 
    public ResponseEntity<Animal> actualizar(@PathVariable Long id, @RequestBody Animal animal){
        try{
            animalService.save(animal);
            return ResponseEntity.ok(animal);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Actualizar parcialmente un animal", description = "Actualiza ciertos campos de un animal")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Animal actualizado parcialmente"), 
        @ApiResponse(responseCode = "404", description = "Animal no encontrado para actualización parcial") 
    }) 
    public ResponseEntity<Animal> patchAnimal(@PathVariable Long id, @RequestBody Animal partialAnimal) {
        try {
            Animal updatedAnimal = animalService.patchAnimal(id, partialAnimal);
            return ResponseEntity.ok(updatedAnimal);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un animal", description = "Elimina un animal por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "204", description = "Animal eliminado exitosamente"), 
        @ApiResponse(responseCode = "404", description = "Animal no encontrado para eliminar") 
    }) 
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            animalService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    //Metodos nuevos agregados a los controller

    @GetMapping("/ciudad/{ciudad}/raza/{raza}")
    @Operation(summary = "Buscar animales por ciudad y raza", description = "Obtiene animales filtrados por ciudad y raza")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"), 
        @ApiResponse(responseCode = "204", description = "No se encontraron animales para los filtros indicados") 
    }) 
    public ResponseEntity<List<Animal>> buscarPorCiudadYRaza(@PathVariable String ciudad, @PathVariable String raza) {
        List<Animal> animales = animalService.buscarPorCiudadYNombreRaza(ciudad, raza);
        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(animales);
    }

    @GetMapping("/adoptados/ciudad/{ciudad}")
    @Operation(summary = "Buscar animales adoptados por ciudad", description = "Obtiene animales adoptados en una ciudad específica")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"), 
        @ApiResponse(responseCode = "204", description = "No se encontraron animales adoptados en esa ciudad") 
    }) 
    public ResponseEntity<List<Animal>> buscarAdoptadosEnCiudad(@PathVariable String ciudad) {
        List<Animal> animales = animalService.buscarAnimalesAdoptadosEnCiudad(ciudad);
        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(animales);
    }

    @GetMapping("/nombre/{nombre}/raza/{raza}")
    @Operation(summary = "Buscar animales por nombre y raza", description = "Obtiene animales que coinciden con el nombre y la raza especificados")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"), 
        @ApiResponse(responseCode = "204", description = "No se encontraron animales para esos parámetros") 
    }) 
    public ResponseEntity<List<Animal>> buscarPorNombreYRaza(@PathVariable String nombre, @PathVariable String raza) {
        List<Animal> animales = animalService.findByNombreAnimalAndRaza_NombreRaza(nombre, raza);
        if (animales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(animales);
    }

}

package com.RefugioHuellasFelices.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import com.RefugioHuellasFelices.model.Categoria;
import com.RefugioHuellasFelices.service.CategoriaService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/categorias")
@Tag(name = "Categorias", description = "Operaciones relacionadas con las categorias")
public class CategoriaController {

    @Autowired
    private CategoriaService categoriaService;

    @GetMapping
    @Operation(summary = "Listar categorías", description = "Obtiene una lista de todas las categorías")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No hay categorías para listar") 
    })
    public ResponseEntity<List<Categoria>> listar(){
        List <Categoria> categorias = categoriaService.findAll();
        if(categorias.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(categorias);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener categoría", description = "Obtiene una categoría por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "404", description = "Categoría no encontrada") 
    })
    public ResponseEntity<Categoria> buscar(@PathVariable Long id){
        try{
            Categoria categoria = categoriaService.findById(id);
            return ResponseEntity.ok(categoria);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/nombre/{nombreCategoria}")
    @Operation(summary = "Buscar categorías por nombre", description = "Obtiene categorías que coinciden con el nombre especificado")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontraron categorías para ese nombre") 
    })
    public ResponseEntity<List<Categoria>> buscarPorNombre(@PathVariable String nombreCategoria) {
        List<Categoria> categorias = categoriaService.findByNombreCategoria(nombreCategoria);
        if (categorias.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(categorias);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva categoría", description = "Crea un nuevo registro de categoría")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Categoría creada exitosamente"),
        @ApiResponse(responseCode = "400", description = "Error en la creación de la categoría") 
    })
    public ResponseEntity<Categoria> guardar(@RequestBody Categoria categoria) {
        Categoria categoriaNuevo = categoriaService.save(categoria);
        return ResponseEntity.status(HttpStatus.CREATED).body(categoriaNuevo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una categoría", description = "Actualiza todos los datos de una categoría existente")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Categoría actualizada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Categoría no encontrada para actualizar") 
    })
    public ResponseEntity<Categoria> actualizar(@PathVariable Long id, @RequestBody Categoria categoria){
        try{
            categoriaService.save(categoria);
            return ResponseEntity.ok(categoria);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Actualizar parcialmente una categoría", description = "Actualiza ciertos campos de una categoría")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Categoría actualizada parcialmente"),
        @ApiResponse(responseCode = "404", description = "Categoría no encontrada para actualización parcial") 
    })
    public ResponseEntity<Categoria> patchCategoria(@PathVariable Long id, @RequestBody Categoria partialCategoria) {
        try {
            Categoria updatedCategoria = categoriaService.patchCategoria(id, partialCategoria);
            return ResponseEntity.ok(updatedCategoria);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una categoría", description = "Elimina una categoría por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "204", description = "Categoría eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Categoría no encontrada para eliminar") 
    })
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            categoriaService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}

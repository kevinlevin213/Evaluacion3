package com.RefugioHuellasFelices.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.RefugioHuellasFelices.controller.CategoriaControllerV2;
import com.RefugioHuellasFelices.model.Categoria;

@Component

public class CategoriaModelAssembler implements RepresentationModelAssembler<Categoria, EntityModel<Categoria>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Categoria> toModel(Categoria categoria) {
        return EntityModel.of(categoria,
        linkTo(methodOn(CategoriaControllerV2.class).findCategoriaById(categoria.getId())).withSelfRel(),
        linkTo(methodOn(CategoriaControllerV2.class).findAllCategorias()).withRel("categorias"),
        linkTo(methodOn(CategoriaControllerV2.class).updateCategoria(categoria.getId(), categoria)).withRel("actualizar"), 
        linkTo(methodOn(CategoriaControllerV2.class).deleteCategoria(categoria.getId())).withRel("eliminar"), 
        linkTo(methodOn(CategoriaControllerV2.class).patchCategoria(categoria.getId(), categoria)).withRel("actualizar-parcial")
        );
    }
}

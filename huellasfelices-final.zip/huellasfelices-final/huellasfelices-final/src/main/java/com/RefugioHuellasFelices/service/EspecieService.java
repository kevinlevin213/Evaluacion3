package com.RefugioHuellasFelices.service;

import java.util.List;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.RefugioHuellasFelices.model.Especie;
import com.RefugioHuellasFelices.repository.EspecieRepository;

@Service
@Transactional

public class EspecieService {

    @Autowired
    private EspecieRepository especieRepository;

    public List<Especie> findAll(){
        return especieRepository.findAll();
    }

    public Especie findById(Long id){
        return especieRepository.findById(id).orElse(null);
    }

    public Especie save(Especie especie){
        return especieRepository.save(especie);
    }

    public void delete(Long id){
        especieRepository.deleteById(id);
    }

    public Especie patchEspecie(Long id, Especie parcialEspecie){
        Optional<Especie> especieOptional = especieRepository.findById(id);
        if (especieOptional.isPresent()) {
            
            Especie especieToUpdate = especieOptional.get();
            
            if (parcialEspecie.getNombreEspecie() != null) {
                especieToUpdate.setNombreEspecie(parcialEspecie.getNombreEspecie());   
            }

            return especieRepository.save(especieToUpdate);
        } else {
            return null; 
        }
    }
    public List<Especie> findByNombreEspecie(String nombreEspecie) {
        return especieRepository.findByNombreEspecie(nombreEspecie);
    }
}

package com.RefugioHuellasFelices.repository;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.RefugioHuellasFelices.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
    
    List<Categoria> findByNombreCategoria(String nombreCategoria);
}

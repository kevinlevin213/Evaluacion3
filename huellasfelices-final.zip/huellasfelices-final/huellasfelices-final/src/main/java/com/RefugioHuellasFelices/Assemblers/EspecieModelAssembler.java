package com.RefugioHuellasFelices.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.RefugioHuellasFelices.controller.EspecieControllerV2;
import com.RefugioHuellasFelices.model.Especie;

@Component
public class EspecieModelAssembler implements RepresentationModelAssembler<Especie, EntityModel<Especie>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Especie> toModel(Especie especie) {
        return EntityModel.of(especie,
        linkTo(methodOn(EspecieControllerV2.class).findEspecieById(especie.getId().longValue())).withSelfRel(),
        linkTo(methodOn(EspecieControllerV2.class).findAllEspecies()).withRel("especies"),
        linkTo(methodOn(EspecieControllerV2.class).updateEspecie(especie.getId().longValue(), especie)).withRel("actualizar"), 
        linkTo(methodOn(EspecieControllerV2.class).deleteEspecie(especie.getId().longValue())).withRel("eliminar"), 
        linkTo(methodOn(EspecieControllerV2.class).patchEspecie(especie.getId().longValue(), especie)).withRel("actualizar-parcial")
        );
    }

}

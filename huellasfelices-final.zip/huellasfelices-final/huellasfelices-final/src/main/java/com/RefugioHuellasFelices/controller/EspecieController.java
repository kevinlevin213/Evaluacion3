package com.RefugioHuellasFelices.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.List;
import com.RefugioHuellasFelices.model.Especie;
import com.RefugioHuellasFelices.service.EspecieService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1/especies")
@Tag(name = "Especies", description = "Operaciones relacionadas con las especies")
public class EspecieController {

    @Autowired
    private EspecieService especieService;

    @GetMapping
    @Operation(summary = "Listar especies", description = "Obtiene una lista de todas las especies")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No hay especies para listar") 
    })
    public ResponseEntity<List<Especie>> listar(){
        List <Especie> especies = especieService.findAll();
        if(especies.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(especies);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Obtener especie", description = "Obtiene una especie por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "404", description = "Especie no encontrada") 
    })
    public ResponseEntity<Especie> buscar(@PathVariable Long id){
        try{
            Especie especie = especieService.findById(id);
            return ResponseEntity.ok(especie);
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @GetMapping("/nombre/{nombreEspecie}")
    @Operation(summary = "Buscar especies por nombre", description = "Obtiene especies que coinciden con el nombre especificado")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Operación exitosa"),
        @ApiResponse(responseCode = "204", description = "No se encontraron especies para ese nombre") 
    })
    public ResponseEntity<List<Especie>> buscarPorNombre(@PathVariable String nombreEspecie) {
        List<Especie> especies = especieService.findByNombreEspecie(nombreEspecie);
        if (especies.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(especies);
    }

    @PostMapping
    @Operation(summary = "Crear una nueva especie", description = "Crea un nuevo registro de especie")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "201", description = "Especie creada exitosamente"),
        @ApiResponse(responseCode = "400", description = "Error en la creación de la especie") 
    })
    public ResponseEntity<Especie> guardar(@RequestBody Especie especie) {
        Especie especieNuevo = especieService.save(especie);
        return ResponseEntity.status(HttpStatus.CREATED).body(especieNuevo);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Actualizar una especie", description = "Actualiza todos los datos de una especie existente")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Especie actualizada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Especie no encontrada para actualizar") 
    })
    public ResponseEntity<Especie> actualizar(@PathVariable Long id, @RequestBody Especie especie){
        try{
            especieService.save(especie);
            return ResponseEntity.ok(especie);
        }catch( Exception e){
            return ResponseEntity.notFound().build();
        }
    }

    @PatchMapping("/{id}")
    @Operation(summary = "Actualizar parcialmente una especie", description = "Actualiza ciertos campos de una especie")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "200", description = "Especie actualizada parcialmente"),
        @ApiResponse(responseCode = "404", description = "Especie no encontrada para actualización parcial") 
    })
    public ResponseEntity<Especie> patchEspecie(@PathVariable Long id, @RequestBody Especie partialEspecie) {
        try {
            Especie updatedEspecie = especieService.patchEspecie(id, partialEspecie);
            return ResponseEntity.ok(updatedEspecie);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
    
    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar una especie", description = "Elimina una especie por su ID")
    @ApiResponses(value = { 
        @ApiResponse(responseCode = "204", description = "Especie eliminada exitosamente"),
        @ApiResponse(responseCode = "404", description = "Especie no encontrada para eliminar") 
    })
    public ResponseEntity<?> eliminar(@PathVariable Long id){
        try{
            especieService.delete(id);
            return ResponseEntity.noContent().build();
        }catch (Exception e){
            return ResponseEntity.notFound().build();
        }
    }
}

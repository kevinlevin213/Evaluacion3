package com.RefugioHuellasFelices.model;

import lombok.Data;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.NoArgsConstructor;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "animal")

public class Animal {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length = 50, nullable = false)
    private String nombreAnimal;
   
    @ManyToOne
    @JoinColumn(name = "ubicacion", nullable = false)
    private Localizacion localizacion;

    @ManyToOne
    @JoinColumn (name = "raza_id", nullable = false)
    private Raza raza;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = true) // puede ser null si no está adoptado
    private Usuario usuario;

}

package com.RefugioHuellasFelices.service;

import java.util.List;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.RefugioHuellasFelices.model.Raza;
import com.RefugioHuellasFelices.repository.RazaRepository;

@Service
@Transactional

public class RazaService {

    @Autowired
    private RazaRepository razaRepository;

    public List<Raza> findAll(){
        return razaRepository.findAll();
    }

    public Raza findById(Long id){
        return razaRepository.findById(id).orElse(null);
    }

    public Raza save(Raza raza){
        return razaRepository.save(raza);
    }

    public void delete(Long id){
        razaRepository.deleteById(id);
    }

    public Raza patchRaza(Long id, Raza parcialRaza){
        Optional<Raza> razaOptional = razaRepository.findById(id);
        if (razaOptional.isPresent()) {
            
            Raza razaToUpdate = razaOptional.get();
            
            if (parcialRaza.getNombreRaza() != null) {
                razaToUpdate.setNombreRaza(parcialRaza.getNombreRaza());   
            }

            return razaRepository.save(razaToUpdate);
        } else {
            return null; 
        }
    }
    public List<Raza> findByNombreRaza(String nombreRaza) {
        return razaRepository.findByNombreRaza(nombreRaza);
    }

    //Nuevos metodos agregados en el service
    public List<Raza> buscarPorNombreEspecie(String especie) {
        return razaRepository.buscarPorNombreEspecie(especie);
    }

    public List<Raza> findByNombreRazaAndEspecie_NombreEspecie(String raza, String especie) {
        return razaRepository.findByNombreRazaAndEspecie_NombreEspecie(raza, especie);
    }

}

package com.RefugioHuellasFelices.repository;

import java.util.List;
import com.RefugioHuellasFelices.model.Usuario;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Usuario findByCorreo(String correo);

    List<Usuario> findByApellidos(String apellidos);

    List<Usuario> findByNombres(String nombres);

    // Esta consulta retorna todos los usuarios que pertenecen a una categoría específica
    // y que están registrados en una ciudad determinada. JOIN Usuario -> Categoria (ManyToOne).
    @Query("SELECT u FROM Usuario u " +
        "JOIN u.categoria c " +                            // JOIN con la tabla 'categoria'
        "WHERE c.nombreCategoria = :nombreCategoria " +    // Filtra por el nombre de la categoría
        "AND u.ciudad = :ciudad")                          // Filtra por ciudad del usuario
    List<Usuario> buscarPorCategoriaYCiudad(@Param("nombreCategoria") String categoria, @Param("ciudad") String ciudad);


    //metodo con minimo 2 parametros 
    Usuario findByCorreoAndRun(String correo, String run);

    @Query("""
            SELECT u.nombres, u.categoria.nombreCategoria FROM Usuario u
            """)
        List<Object[]>  findByUsuarioConCategoria();
}
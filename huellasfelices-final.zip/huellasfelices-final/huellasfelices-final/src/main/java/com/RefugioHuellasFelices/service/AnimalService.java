package com.RefugioHuellasFelices.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.RefugioHuellasFelices.model.Animal;
import com.RefugioHuellasFelices.repository.AnimalRepository;



@Service
@Transactional

public class AnimalService {

    @Autowired
    private AnimalRepository animalRepository;

    public List<Animal> findAll(){
        return animalRepository.findAll();
    }

    public Animal findById(Long id){
        return animalRepository.findById(id).orElse(null);
    }

    public Animal save(Animal animal){
        return animalRepository.save(animal);
    }

    public void delete(Long id){
        animalRepository.deleteById(id);
    }

    public Animal patchAnimal(Long id, Animal parcialAnimal){
        Optional<Animal> animalOptional = animalRepository.findById(id);
        if (animalOptional.isPresent()) {
            
            Animal animalToUpdate = animalOptional.get();
             
            if (parcialAnimal.getNombreAnimal() != null) {
                animalToUpdate.setNombreAnimal(parcialAnimal.getNombreAnimal());   
            }
            return animalRepository.save(animalToUpdate);
        } else {
            return null; 
        }
    }

    public List<Animal> findByNombreAnimal(String nombreAnimal) {
        return animalRepository.findByNombreAnimal(nombreAnimal);
    }

    public List<Map<String, Object>> findAnimalConDireccion() {
        List<Object[]> resultados = animalRepository.findByAnimalConDireccion();
        List<Map<String, Object>> lista = new ArrayList<>();

        for (Object[] fila : resultados) {
            Map<String, Object> datos = new HashMap<>();
            datos.put("Nombre_animal", fila[0]);
            datos.put("nombre_direccion", fila[1]);
            lista.add(datos);
        }

        return lista;
    }


    //Nuevos metodos agregados en el service
    public List<Animal> buscarPorCiudadYNombreRaza(String ciudad, String raza) {
        return animalRepository.buscarPorCiudadYNombreRaza(ciudad, raza);
    }

    public List<Animal> buscarAnimalesAdoptadosEnCiudad(String ciudad) {
        return animalRepository.buscarAnimalesAdoptadosEnCiudad(ciudad);
    }

    public List<Animal> findByNombreAnimalAndRaza_NombreRaza(String nombre, String raza) {
        return animalRepository.findByNombreAnimalAndRaza_NombreRaza(nombre, raza);
    }

}

package com.RefugioHuellasFelices.repository;

import java.util.List;
import com.RefugioHuellasFelices.model.Animal;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface AnimalRepository extends JpaRepository<Animal, Long> {

    

    // Esta consulta busca todos los animales cuya ciudad de localización coincide con el parámetro "ciudad"
    // y cuya raza coincide con el parámetro "raza". Hace un JOIN entre Animal -> Localizacion y Animal -> Raza.
    @Query("SELECT a FROM Animal a " +
        "JOIN a.localizacion l " +  // JOIN con la tabla 'localizacion' usando la relación ManyToOne
        "JOIN a.raza r " +          // JOIN con la tabla 'raza' usando la relación ManyToOne
        "WHERE l.ciudad = :ciudad AND r.nombreRaza = :raza")
    List<Animal> buscarPorCiudadYNombreRaza(@Param("ciudad") String ciudad, @Param("raza") String raza);

    // Esta consulta retorna todos los animales que ya han sido adoptados (es decir, tienen un usuario asignado)
    // y que viven en una ciudad específica. JOIN Animal -> Usuario (ManyToOne).
    @Query("SELECT a FROM Animal a " +
        "JOIN a.usuario u " +              // JOIN con la tabla 'usuario' (solo animales con usuario asignado)
        "WHERE u.ciudad = :ciudad")        // Filtra por ciudad del usuario
    List<Animal> buscarAnimalesAdoptadosEnCiudad(@Param("ciudad") String ciudad);


    // metodos con minimo 2 parametros
    List<Animal> findByNombreAnimalAndRaza_NombreRaza(String nombre, String raza);

    
    List<Animal> findByNombreAnimal(String nombreAnimal);

            @Query("""
            SELECT a.nombreAnimal, a.localizacion.direccion FROM Animal a
            """)
        List<Object[]>  findByAnimalConDireccion();

        
}

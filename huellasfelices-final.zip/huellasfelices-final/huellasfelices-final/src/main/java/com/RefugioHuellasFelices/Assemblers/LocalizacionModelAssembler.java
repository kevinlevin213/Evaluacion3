package com.RefugioHuellasFelices.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.RefugioHuellasFelices.controller.LocalizacionControllerV2;
import com.RefugioHuellasFelices.model.Localizacion;

@Component
public class LocalizacionModelAssembler implements RepresentationModelAssembler<Localizacion, EntityModel<Localizacion>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Localizacion> toModel(Localizacion localizacion) {
        return EntityModel.of(localizacion,
        linkTo(methodOn(LocalizacionControllerV2.class).findLocalizacionById(localizacion.getId())).withSelfRel(),
        linkTo(methodOn(LocalizacionControllerV2.class).findAllLocalizacion()).withRel("localizaciones"),
        linkTo(methodOn(LocalizacionControllerV2.class).updateLocalizacion(localizacion.getId(), localizacion)).withRel("actualizar"), 
        linkTo(methodOn(LocalizacionControllerV2.class).deleteLocalizacion(localizacion.getId())).withRel("eliminar"), 
        linkTo(methodOn(LocalizacionControllerV2.class).patchLocalizacion(localizacion.getId(), localizacion)).withRel("actualizar-parcial") 
        );
    }

}

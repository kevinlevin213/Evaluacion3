package com.RefugioHuellasFelices.controller;


import com.RefugioHuellasFelices.Assemblers.LocalizacionModelAssembler;
import com.RefugioHuellasFelices.model.Localizacion;
import com.RefugioHuellasFelices.service.LocalizacionService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/localizaciones")

public class LocalizacionControllerV2 {

    @Autowired
    private LocalizacionService localizacionService;

    @Autowired
    private LocalizacionModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Localizacion>> findAllLocalizacion() {
        List<EntityModel<Localizacion>> localizaciones = localizacionService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(localizaciones,
                linkTo(methodOn(LocalizacionControllerV2.class).findAllLocalizacion()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Localizacion>> findLocalizacionById(@PathVariable Long id) {
        Localizacion localizacion = localizacionService.findById(id);
        if (localizacion == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(localizacion));
    }

    @GetMapping(value = "/ciudad/{ciudad}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Localizacion>> findByCiudad(@PathVariable String ciudad) {
        Localizacion localizacion = localizacionService.findByCiudad(ciudad);
        if (localizacion == null) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(assembler.toModel(localizacion));
    }

    @GetMapping(value = "/comuna/{comuna}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Localizacion>> findByComuna(@PathVariable String comuna) {
        List<EntityModel<Localizacion>> localizaciones = localizacionService.findByComuna(comuna).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(localizaciones,
                linkTo(methodOn(LocalizacionControllerV2.class).findByComuna(comuna)).withSelfRel());
    }

    @GetMapping(value = "/comuna/{comuna}/ciudad/{ciudad}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Localizacion>> findByComunaAndCiudad(@PathVariable String comuna, @PathVariable String ciudad) {
        List<EntityModel<Localizacion>> localizaciones = localizacionService.findByComunaAndCiudad(comuna, ciudad).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(localizaciones,
                linkTo(methodOn(LocalizacionControllerV2.class).findByComunaAndCiudad(comuna, ciudad)).withSelfRel());
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Localizacion>> createLocalizacion(@RequestBody Localizacion localizacion) {
        Localizacion nueva = localizacionService.save(localizacion);
        return ResponseEntity
                .created(linkTo(methodOn(LocalizacionControllerV2.class).findLocalizacionById(nueva.getId().longValue())).toUri())
                .body(assembler.toModel(nueva));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Localizacion>> updateLocalizacion(@PathVariable Long id, @RequestBody Localizacion localizacion) {
        localizacion.setId(id);
        Localizacion actualizada = localizacionService.save(localizacion);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(actualizada));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Localizacion>> patchLocalizacion(@PathVariable Long id, @RequestBody Localizacion localizacion) {
        Localizacion actualizada = localizacionService.patchLocalizacion(id, localizacion);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(actualizada));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<Void> deleteLocalizacion(@PathVariable Long id) {
        Localizacion existente = localizacionService.findById(id);
        if (existente == null) {
            return ResponseEntity.notFound().build();
        }
        localizacionService.delete(id);
        return ResponseEntity.noContent().build();
    }




}

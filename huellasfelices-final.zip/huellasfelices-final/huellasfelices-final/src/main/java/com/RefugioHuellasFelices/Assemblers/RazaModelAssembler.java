package com.RefugioHuellasFelices.Assemblers;

import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.RefugioHuellasFelices.controller.RazaControllerV2;
import com.RefugioHuellasFelices.model.Raza;

@Component
public class RazaModelAssembler implements RepresentationModelAssembler<Raza, EntityModel<Raza>> {

    @SuppressWarnings("null")
    @Override
    public EntityModel<Raza> toModel(Raza raza) {
        return EntityModel.of(raza,
        linkTo(methodOn(RazaControllerV2.class).findRazaById(raza.getId().longValue())).withSelfRel(),
        linkTo(methodOn(RazaControllerV2.class).findAllRaza()).withRel("razas"),
        linkTo(methodOn(RazaControllerV2.class).updateRaza(raza.getId().longValue(), raza)).withRel("actualizar"), 
        linkTo(methodOn(RazaControllerV2.class).deleteRaza(raza.getId().longValue())).withRel("eliminar"), 
        linkTo(methodOn(RazaControllerV2.class).patchRaza(raza.getId().longValue(), raza)).withRel("actualizar-parcial")
        );
    }

}

package com.RefugioHuellasFelices.repository;

import java.util.List;
import org.springframework.stereotype.Repository;
import com.RefugioHuellasFelices.model.Localizacion;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface LocalizacionRepository extends JpaRepository<Localizacion, Long> {

    Localizacion findByCiudad(String ciudad);

    List<Localizacion> findByComuna(String comuna);

    //metodo con minimo 2 parametros
    List<Localizacion> findByComunaAndCiudad(String comuna, String ciudad);
}

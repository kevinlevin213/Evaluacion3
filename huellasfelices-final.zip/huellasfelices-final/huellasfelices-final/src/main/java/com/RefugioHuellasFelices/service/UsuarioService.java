package com.RefugioHuellasFelices.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.RefugioHuellasFelices.model.Usuario;
import com.RefugioHuellasFelices.repository.UsuarioRepository;

import jakarta.transaction.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@Transactional

public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    public List<Usuario> findAll(){
        return usuarioRepository.findAll();
    }

    public Usuario findById(Long id){
        return usuarioRepository.findById(id).orElse(null);
    }

    public Usuario save(Usuario usuario){
        return usuarioRepository.save(usuario);
    }

    public void delete(Long id){
        usuarioRepository.deleteById(id);
    }

    public Usuario patchUsuario(Long id, Usuario parcialUsuario){
        Optional<Usuario> usuarioOptional = usuarioRepository.findById(id);
        if (usuarioOptional.isPresent()) {
            
            Usuario usuarioToUpdate = usuarioOptional.get();
            
            if (parcialUsuario.getNombres() != null) {
                usuarioToUpdate.setNombres(parcialUsuario.getNombres());   
            }

            if(parcialUsuario.getApellidos() != null) {
                usuarioToUpdate.setApellidos(parcialUsuario.getApellidos());
            }

            if(parcialUsuario.getCorreo() != null) {
                usuarioToUpdate.setCorreo(parcialUsuario.getCorreo());
            }

            if(parcialUsuario.getContraseña() != null) {
                usuarioToUpdate.setContraseña(parcialUsuario.getContraseña());
            }

            if(parcialUsuario.getTelefono() != null) {
                usuarioToUpdate.setTelefono(parcialUsuario.getTelefono());
            }

            if(parcialUsuario.getCiudad() != null) {
                usuarioToUpdate.setCiudad(parcialUsuario.getCiudad());
            }

            return usuarioRepository.save(usuarioToUpdate);
        } else {
            return null; 
        }
    }
    public Usuario findByCorreo(String correo) {
        return usuarioRepository.findByCorreo(correo);
    }

    public List<Usuario> findByApellidos(String apellidos) {
        return usuarioRepository.findByApellidos(apellidos);
    }

    public List<Usuario> findByNombres(String nombres) {
        return usuarioRepository.findByNombres(nombres);
    }

    public List<Map<String, Object>> findUsuarioConCategoria() {
        List<Object[]> resultados = usuarioRepository.findByUsuarioConCategoria();
        List<Map<String, Object>> lista = new ArrayList<>();

        for (Object[] fila : resultados) {
            Map<String, Object> datos = new HashMap<>();
            datos.put("Nombre_usuario", fila[0]);
            datos.put("nombre_categoria", fila[1]);
            lista.add(datos);
        }

        return lista;
    }

    //Nuevos metodos agregados en el service
    public List<Usuario> buscarPorCategoriaYCiudad(String categoria, String ciudad) {
        return usuarioRepository.buscarPorCategoriaYCiudad(categoria, ciudad);
    }

    public Usuario findByCorreoAndRun(String correo, String run) {
        return usuarioRepository.findByCorreoAndRun(correo, run);
    }


    public Usuario updateUsuario(Long id, Usuario usuario) {
        Usuario usuarioToUpdate = usuarioRepository.findById(id).orElse(null);
        if (usuarioToUpdate != null) {
            usuarioToUpdate.setNombres(usuario.getNombres());
            usuarioToUpdate.setApellidos(usuario.getApellidos());
            usuarioToUpdate.setRun(usuario.getRun());
            usuarioToUpdate.setCorreo(usuario.getCorreo());
            usuarioToUpdate.setContraseña(usuario.getContraseña());
            usuarioToUpdate.setTelefono(usuario.getTelefono());
            usuarioToUpdate.setCiudad(usuario.getCiudad());
            return usuarioRepository.save(usuarioToUpdate);
        } else {
            return null;
        }
    }

}
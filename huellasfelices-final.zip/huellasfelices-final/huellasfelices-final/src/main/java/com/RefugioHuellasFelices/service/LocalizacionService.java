package com.RefugioHuellasFelices.service;

import java.util.List;
import java.util.Optional;

import jakarta.transaction.Transactional;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

import com.RefugioHuellasFelices.model.Localizacion;
import com.RefugioHuellasFelices.repository.LocalizacionRepository;

@Service
@Transactional

public class LocalizacionService {

    @Autowired
    private LocalizacionRepository localizacionRepository;

    public List<Localizacion> findAll(){
        return localizacionRepository.findAll();
    }

    public Localizacion findById(Long id){
        return localizacionRepository.findById(id).orElse(null);
    }

    public Localizacion save(Localizacion localizacion){
        return localizacionRepository.save(localizacion);
    }

    public void delete(Long id){
        localizacionRepository.deleteById(id);
    }

    public Localizacion patchLocalizacion(Long id, Localizacion parcialLocalizacion){
        Optional<Localizacion> localizacionOptional = localizacionRepository.findById(id);
        if (localizacionOptional.isPresent()) {
            
            Localizacion localizacionToUpdate = localizacionOptional.get();
            
            if (parcialLocalizacion.getDireccion() != null) {
                localizacionToUpdate.setDireccion(parcialLocalizacion.getDireccion());   
            }

            if(parcialLocalizacion.getComuna() != null) {
                localizacionToUpdate.setComuna(parcialLocalizacion.getComuna());
            }

            if(parcialLocalizacion.getCiudad() != null) {
                localizacionToUpdate.setCiudad(parcialLocalizacion.getCiudad());
            }

            return localizacionRepository.save(localizacionToUpdate);
        } else {
            return null; 
        }
    }
    public Localizacion findByCiudad(String ciudad) {
        return localizacionRepository.findByCiudad(ciudad);
    }

    public List<Localizacion> findByComuna(String comuna) {
        return localizacionRepository.findByComuna(comuna);
    }

    //Metodos agregados en el service
    public List<Localizacion> findByComunaAndCiudad(String comuna, String ciudad) {
        return localizacionRepository.findByComunaAndCiudad(comuna, ciudad);
    }

}

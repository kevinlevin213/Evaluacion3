package com.RefugioHuellasFelices.controller;

import com.RefugioHuellasFelices.Assemblers.EspecieModelAssembler;
import com.RefugioHuellasFelices.model.Especie;
import com.RefugioHuellasFelices.service.EspecieService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.MediaTypes;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v2/especies")
public class EspecieControllerV2 {

@Autowired
    private EspecieService especieService;

    @Autowired
    private EspecieModelAssembler assembler;

    @GetMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Especie>> findAllEspecies() {
        List<EntityModel<Especie>> especies = especieService.findAll().stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(especies,
                linkTo(methodOn(EspecieControllerV2.class).findAllEspecies()).withSelfRel());
    }

    @GetMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Especie>> findEspecieById(@PathVariable Long id) {
        Especie especie = especieService.findById(id);
        if (especie == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(especie));
    }

    @GetMapping(value = "/nombre/{nombre}", produces = MediaTypes.HAL_JSON_VALUE)
    public CollectionModel<EntityModel<Especie>> findEspecieByNombre(@PathVariable String nombre) {
        List<EntityModel<Especie>> especies = especieService.findByNombreEspecie(nombre).stream()
                .map(assembler::toModel)
                .collect(Collectors.toList());

        return CollectionModel.of(
                especies,
                linkTo(methodOn(EspecieControllerV2.class).findEspecieByNombre(nombre)).withSelfRel()
        );
    }

    @PostMapping(produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Especie>> createEspecie(@RequestBody Especie especie) {
        Especie nueva = especieService.save(especie);
        return ResponseEntity
                .created(linkTo(methodOn(EspecieControllerV2.class).findEspecieById(nueva.getId().longValue())).toUri())
                .body(assembler.toModel(nueva));
    }

    @PutMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Especie>> updateEspecie(@PathVariable Long id, @RequestBody Especie especie) {
        Especie actualizada = especieService.save(especie);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(actualizada));
    }

    @PatchMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<EntityModel<Especie>> patchEspecie(@PathVariable Long id, @RequestBody Especie especie) {
        Especie actualizada = especieService.patchEspecie(id, especie);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(assembler.toModel(actualizada));
    }

    @DeleteMapping(value = "/{id}", produces = MediaTypes.HAL_JSON_VALUE)
    public ResponseEntity<Void> deleteEspecie(@PathVariable Long id) {
        Especie especie = especieService.findById(id);
        if (especie == null) {
            return ResponseEntity.notFound().build();
        }
        especieService.delete(id);
        return ResponseEntity.noContent().build();
    }



}

package com.RefugioHuellasFelices.HuellasFelices.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;


import com.RefugioHuellasFelices.model.Especie;
import com.RefugioHuellasFelices.service.EspecieService;
import com.RefugioHuellasFelices.repository.EspecieRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest

public class EspecieServiceTest {

    @Autowired
    private EspecieService EspecieService;

    @MockBean
    private EspecieRepository especieRepository;

    private Especie createEspecie() {
        Especie especie = new Especie();
        especie.setId(1);
        especie.setNombreEspecie("Especie Prueba");
        return especie;
    }

    @Test
    public void testFindAll() {
        when(especieRepository.findAll()).thenReturn(List.of(createEspecie()));
        List<Especie> especies = EspecieService.findAll();
        assertNotNull(especies);
        assertEquals(1, especies.size());
    }

    @Test
    public void testFindById() {
        when(especieRepository.findById(1L)).thenReturn(java.util.Optional.of(createEspecie()));
        Especie especie = EspecieService.findById(1L);
        assertNotNull(especie);
        assertEquals("Especie Prueba", especie.getNombreEspecie());
    }


    @Test
    public void testSave() {
        Especie especie = createEspecie();
        when(especieRepository.save(especie)).thenReturn(especie);
        Especie saved = EspecieService.save(especie);
        assertNotNull(saved);
        assertEquals("Especie Prueba", saved.getNombreEspecie());
    }

    @Test
    public void testPatchEspecie() {
        Especie especie = createEspecie();
        especie.setNombreEspecie("Nuevo Especie");
        when(especieRepository.findById(1L)).thenReturn(java.util.Optional.of(createEspecie()));
        when(especieRepository.save(especie)).thenReturn(especie);
        Especie patched = EspecieService.patchEspecie(1L, especie);
        assertNotNull(patched);
        assertEquals("Nuevo Especie", patched.getNombreEspecie());
    }


    @Test
    public void testDeleteById() {
        Especie especie = createEspecie();
        when(especieRepository.findById(1L)).thenReturn(java.util.Optional.of(especie));
        EspecieService.delete(1L);
        when(especieRepository.findById(1L)).thenReturn(java.util.Optional.empty());
        assertEquals(java.util.Optional.empty(), especieRepository.findById(1L));
    }

}

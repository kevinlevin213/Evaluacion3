package com.RefugioHuellasFelices.HuellasFelices.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;

import com.RefugioHuellasFelices.model.Categoria;
import com.RefugioHuellasFelices.service.CategoriaService;
import com.RefugioHuellasFelices.repository.CategoriaRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest

public class CategoriaServiceTest {

    @Autowired
    private CategoriaService categoriaService;

    @MockBean
    private CategoriaRepository categoriaRepository;

    private Categoria createCategoria() {
        Categoria categoria = new Categoria();
        categoria.setId(1L);
        categoria.setNombreCategoria("Categoria de prueba");
        return categoria;
    }
    @Test
    public void testFindAll() {
        when(categoriaRepository.findAll()).thenReturn(List.of(createCategoria()));
        List<Categoria> categorias = categoriaService.findAll();
        assertNotNull(categorias);
        assertEquals(1, categorias.size());
    }
    @Test
    public void testFindById() {
        when(categoriaRepository.findById(1L)).thenReturn(java.util.Optional.of(createCategoria()));
        Categoria categoria = categoriaService.findById(1L);
        assertNotNull(categoria);
        assertEquals("Categoria de prueba", categoria.getNombreCategoria());
    }
    @Test
    public void testSave() {
        Categoria categoria = createCategoria();
        when(categoriaRepository.save(categoria)).thenReturn(categoria);
        Categoria saved = categoriaService.save(categoria);
        assertNotNull(saved);
        assertEquals("Categoria de prueba", saved.getNombreCategoria());
    }
    @Test
    public void testPatchCategoria() {
        Categoria categoria = createCategoria();
        categoria.setNombreCategoria("Nueva Categoria");
        when(categoriaRepository.findById(1L)).thenReturn(java.util.Optional.of(createCategoria()));
        when(categoriaRepository.save(categoria)).thenReturn(categoria);
        Categoria patched = categoriaService.patchCategoria(1L, categoria);
        assertNotNull(patched);
        assertEquals("Nueva Categoria", patched.getNombreCategoria());
    }
    @Test
    public void testDeleteById() {
        Categoria categoria = createCategoria();
        when(categoriaRepository.findById(1L)).thenReturn(java.util.Optional.of(categoria));
        categoriaService.delete(1L);
        when(categoriaRepository.findById(1L)).thenReturn(java.util.Optional.empty());
        assertEquals(java.util.Optional.empty(), categoriaRepository.findById(1L));
    }

}

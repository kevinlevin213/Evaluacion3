package com.RefugioHuellasFelices.HuellasFelices.test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;

import com.RefugioHuellasFelices.model.Animal;
import com.RefugioHuellasFelices.service.AnimalService;
import com.RefugioHuellasFelices.repository.AnimalRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;



@SpringBootTest
public class AnimalServiceTest {

    @Autowired
    private AnimalService AnimalService;

    @MockBean
    private AnimalRepository animalRepository;

    private Animal createAnimal() {
        Animal animal = new Animal();
        animal.setId(1L);
        animal.setNombreAnimal("Animal Prueba");
        return animal;
    }

    @Test
    public void testFindAll() {
        when(animalRepository.findAll()).thenReturn(List.of(createAnimal()));
        List<Animal> animales = AnimalService.findAll();
        assertNotNull(animales);
        assertEquals(1, animales.size());
    }

    @Test
    public void testFindById() {
        when(animalRepository.findById(1L)).thenReturn(java.util.Optional.of(createAnimal()));
        Animal animal = AnimalService.findById(1L);
        assertNotNull(animal);
        assertEquals("Animal Prueba", animal.getNombreAnimal());
    }

    @Test
    public void testSave() {
        Animal animal = createAnimal();
        when(animalRepository.save(animal)).thenReturn(animal);
        Animal saved = AnimalService.save(animal);
        assertNotNull(saved);
        assertEquals("Animal Prueba", saved.getNombreAnimal());
    }

    @Test
    public void testPatchAnimal() {
        Animal animal = createAnimal();
        animal.setNombreAnimal("Nuevo Animal");
        when(animalRepository.findById(1L)).thenReturn(java.util.Optional.of(createAnimal()));
        when(animalRepository.save(animal)).thenReturn(animal);
        Animal patched = AnimalService.patchAnimal(1L, animal);
        assertNotNull(patched);
        assertEquals("Nuevo Animal", patched.getNombreAnimal());
    }

    @Test
    public void testDeleteById() {
        Animal animal = createAnimal();
        when(animalRepository.findById(1L)).thenReturn(java.util.Optional.of(animal));
        AnimalService.delete(1L);
        when(animalRepository.findById(1L)).thenReturn(java.util.Optional.empty());
        assertEquals(java.util.Optional.empty(), animalRepository.findById(1L));
    }

}

package com.RefugioHuellasFelices.HuellasFelices.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;

import com.RefugioHuellasFelices.model.Localizacion;
import com.RefugioHuellasFelices.service.LocalizacionService;
import com.RefugioHuellasFelices.repository.LocalizacionRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest

public class LocalizacionServiceTest {

    @Autowired
    private LocalizacionService localizacionService;

    @MockBean
    private LocalizacionRepository localizacionRepository;

    private Localizacion createLocalizacion() {
        Localizacion localizacion = new Localizacion();
        localizacion.setId(1L);
        localizacion.setDireccion("Dirección de prueba");
        localizacion.setComuna("Comuna de prueba");
        localizacion.setCiudad("Ciudad de prueba");
        return localizacion;
    }

    @Test
    public void testFindAll() {
        when(localizacionRepository.findAll()).thenReturn(List.of(createLocalizacion()));
        List<Localizacion> localizaciones = localizacionService.findAll();
        assertNotNull(localizaciones);
        assertEquals(1, localizaciones.size());
    }

    @Test
    public void testFindById() {
        when(localizacionRepository.findById(1L)).thenReturn(java.util.Optional.of(createLocalizacion()));
        Localizacion localizacion = localizacionService.findById(1L);
        assertNotNull(localizacion);
        assertEquals("Dirección de prueba", localizacion.getDireccion());
        assertEquals("Comuna de prueba", localizacion.getComuna());
        assertEquals("Ciudad de prueba", localizacion.getCiudad());
    }

    @Test
    public void testSave() {
        Localizacion localizacion = createLocalizacion();
        when(localizacionRepository.save(localizacion)).thenReturn(localizacion);
        Localizacion saved = localizacionService.save(localizacion);
        assertNotNull(saved);
        assertEquals("Dirección de prueba", localizacion.getDireccion());
        assertEquals("Comuna de prueba", localizacion.getComuna());
        assertEquals("Ciudad de prueba", localizacion.getCiudad());
    }

    @Test
    public void testPatchLocalizacion() {
        Localizacion localizacion = createLocalizacion();
        localizacion.setDireccion("Nueva Direccion");
        localizacion.setComuna("Nueva Comuna");
        localizacion.setCiudad("Nueva Ciudad");
        when(localizacionRepository.findById(1L)).thenReturn(java.util.Optional.of(createLocalizacion()));
        when(localizacionRepository.save(localizacion)).thenReturn(localizacion);
        Localizacion patched = localizacionService.patchLocalizacion(1L, localizacion);
        assertNotNull(patched);
        assertEquals("Nueva Direccion", patched.getDireccion());
        assertEquals("Nueva Comuna", patched.getComuna());
        assertEquals("Nueva Ciudad", patched.getCiudad());
    }

    @Test
    public void testDeleteById() {
        Localizacion localizacion = createLocalizacion();
        when(localizacionRepository.findById(1L)).thenReturn(java.util.Optional.of(localizacion));
        localizacionService.delete(1L);
        when(localizacionRepository.findById(1L)).thenReturn(java.util.Optional.empty());
        assertEquals(java.util.Optional.empty(), localizacionRepository.findById(1L));
    }


}

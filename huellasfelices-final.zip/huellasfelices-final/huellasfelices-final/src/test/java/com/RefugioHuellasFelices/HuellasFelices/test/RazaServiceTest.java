package com.RefugioHuellasFelices.HuellasFelices.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.List;


import com.RefugioHuellasFelices.model.Raza;

import com.RefugioHuellasFelices.service.RazaService;

import com.RefugioHuellasFelices.repository.RazaRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest

public class RazaServiceTest {

    @Autowired
    private RazaService RazaService;

    @MockBean
    private RazaRepository razaRepository;

    private Raza createRaza() {
        Raza raza = new Raza();
        raza.setId(1L);
        raza.setNombreRaza("Raza Prueba");
        return raza;
    }

    @Test
    public void testFindAll() {
        when(razaRepository.findAll()).thenReturn(List.of(createRaza()));
        List<Raza> razas = RazaService.findAll();
        assertNotNull(razas);
        assertEquals(1, razas.size());
    }

    @Test
    public void testFindById() {
        when(razaRepository.findById(1L)).thenReturn(java.util.Optional.of(createRaza()));
        Raza raza = RazaService.findById(1L);
        assertNotNull(raza);
        assertEquals("Raza Prueba", raza.getNombreRaza());
    }


    @Test
    public void testSave() {
        Raza raza = createRaza();
        when(razaRepository.save(raza)).thenReturn(raza);
        Raza saved = RazaService.save(raza);
        assertNotNull(saved);
        assertEquals("Raza Prueba", saved.getNombreRaza());
    }

    @Test
    public void testPatchRaza() {
        Raza raza  = createRaza();
        raza.setNombreRaza("Nuevo Raza");
        when(razaRepository.findById(1L)).thenReturn(java.util.Optional.of(createRaza()));
        when(razaRepository.save(raza)).thenReturn(raza);
        Raza patched = RazaService.patchRaza(1L, raza);
        assertNotNull(patched);
        assertEquals("Nuevo Raza", patched.getNombreRaza());
    }


    @Test
    public void testDeleteById() {
        Raza raza = createRaza();
        when(razaRepository.findById(1L)).thenReturn(java.util.Optional.of(raza));
        RazaService.delete(1L);
        when(razaRepository.findById(1L)).thenReturn(java.util.Optional.empty());
        assertEquals(java.util.Optional.empty(), razaRepository.findById(1L));
    }

}

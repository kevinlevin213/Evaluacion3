package com.RefugioHuellasFelices.HuellasFelices.test;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;

import com.RefugioHuellasFelices.model.Usuario;
import com.RefugioHuellasFelices.service.UsuarioService;
import com.RefugioHuellasFelices.repository.UsuarioRepository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@SpringBootTest
public class UsuarioServiceTest {

    @Autowired
    private UsuarioService usuarioService;

    @MockBean
    private UsuarioRepository usuarioRepository;

    private Usuario createUsuario() {
        Usuario usuario = new Usuario();
        usuario.setId(1L);
        usuario.setRun("99999999-9");
        usuario.setNombres("Kevin");
        usuario.setApellidos("Morales");
        usuario.setCorreo("kevin@kevin.com");
        usuario.setContraseña("Kevin54321");
        usuario.setTelefono("123456789");
        usuario.setCiudad("Calle Imaginaria 123");
        return usuario;
    }

    @Test
    public void testFindAll() {
        when(usuarioRepository.findAll()).thenReturn(List.of(createUsuario()));
        List<Usuario> usuarios = usuarioService.findAll();
        assertNotNull(usuarios);
        assertEquals(1, usuarios.size());
    }

    @Test
    public void testFindById() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(createUsuario()));
        Usuario usuario = usuarioService.findById(1L);
        assertNotNull(usuario);
        assertEquals("Kevin", usuario.getNombres());
        assertEquals("Morales", usuario.getApellidos());
        assertEquals("99999999-9", usuario.getRun());
        assertEquals("kevin@kevin.com", usuario.getCorreo());
        assertEquals("Kevin54321", usuario.getContraseña());
        assertEquals("123456789", usuario.getTelefono());
        assertEquals("Calle Imaginaria 123", usuario.getCiudad());
        
    }

    @Test
    public void testSave() {
        Usuario usuario = createUsuario();
        when(usuarioRepository.save(usuario)).thenReturn(usuario);
        Usuario saved = usuarioService.save(usuario);
        assertNotNull(saved);
        assertEquals("Kevin", usuario.getNombres());
        assertEquals("Morales", usuario.getApellidos());
        assertEquals("99999999-9", usuario.getRun());
        assertEquals("kevin@kevin.com", usuario.getCorreo());
        assertEquals("Kevin54321", usuario.getContraseña());
        assertEquals("123456789", usuario.getTelefono());
        assertEquals("Calle Imaginaria 123", usuario.getCiudad());
    }

    @Test
    public void testDelete() {
        doNothing().when(usuarioRepository).deleteById(1L);
        usuarioService.delete(1L);
        verify(usuarioRepository, times(1)).deleteById(1L);
    }

    @Test
    public void testUpdateUsuario() {
        Usuario usuario = createUsuario();
        Usuario actualizado = createUsuario();
        actualizado.setNombres("Nombre Actualizado");
        actualizado.setApellidos("Apellido Actualizado");
        actualizado.setRun("Run Actualizado");
        actualizado.setCorreo("Correo Actualizado");
        actualizado.setTelefono("Telefono Actualizado");
        actualizado.setContraseña("Contraseña Actualizado");
        actualizado.setCiudad("Ciudad Actualizado");

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuario));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuario);

        Usuario result = usuarioService.updateUsuario(1L, actualizado);
        assertNotNull(result);
        assertEquals("Nombre Actualizado", result.getNombres());
        assertEquals("Apellido Actualizado", result.getApellidos());
        assertEquals("Run Actualizado", result.getRun());
        assertEquals("Correo Actualizado", result.getCorreo());
        assertEquals("Telefono Actualizado", result.getTelefono());
        assertEquals("Contraseña Actualizado", result.getContraseña());
        assertEquals("Ciudad Actualizado", result.getCiudad());

    }

    @Test
    public void testPatchUsuario() {
        Usuario original = createUsuario();
        Usuario patch = new Usuario();
        patch.setNombres("Parcial Nombres");
        patch.setApellidos("Parcial Apellidos");
        patch.setRun("Parcial Run");
        patch.setCorreo("Parcial Correo");
        patch.setContraseña("Parcial Contraseña");
        patch.setTelefono("Parcial Telefono");
        patch.setCiudad("Parcial Ciudad");

        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(original));
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(original);

        Usuario result = usuarioService.patchUsuario(1L, patch);
        assertNotNull(result);
        assertEquals("Parcial Nombres", result.getNombres());
        assertEquals("Parcial Apellidos", result.getApellidos());
        assertEquals("Parcial Correo", result.getCorreo());
        assertEquals("Parcial Contraseña", result.getContraseña());
        assertEquals("Parcial Telefono", result.getTelefono());
        assertEquals("Parcial Ciudad", result.getCiudad());

    }

}
